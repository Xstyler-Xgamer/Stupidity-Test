EN:
Hello!
thank you so much for deciding to play “Stupidity Test”! hope you have a lot of fun!
but note that any changes to the files can lead to errors! 

DE:
Hallo!
vielen dank, dass du dich entschieden hast, „Stupidity Test“ zu spielen! Ich hoffe, du hast viel Spaß!
beachte aber, dass jegliche Änderungen an den Dateien zu Fehlern führen können! 